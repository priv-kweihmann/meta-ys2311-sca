#!/bin/customshell
## SPDX-License-Identifier: BSD-2-Clause
## Copyright (c) 2023, Konrad Weihmann

## A shell script mimicking the bad stuff coming from binary blobs
random_magic || true
